import 'package:flutter/material.dart';
import 'package:audioplayers/audio_cache.dart';

void main() => runApp(XylophoneApp());

class XylophoneApp extends StatelessWidget {
  final player = AudioCache();
    void soundPlayer(int number){
        player.play("note$number.wav");
  }
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: SafeArea(
          child: Container(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
              Expanded(
                child: FlatButton(
                  color:Colors.blue,
                  onPressed: (){
                  soundPlayer(1);
                },
                ),
              ),
                Expanded(
                  child: FlatButton(
                    color:Colors.indigo,

                    onPressed: (){
                      soundPlayer(2);
                    },
                  ),
                ),
                Expanded(
                  child: FlatButton(
                    color:Colors.blueAccent,
                    onPressed: (){
                      soundPlayer(3);
                    },
                  ),
                ),
                Expanded(
                  child: FlatButton(
                    color:Colors.red,
                    onPressed: (){
                      soundPlayer(4);
                    },
                  ),
                ),
                Expanded(
                  child: FlatButton(
                    color:Colors.yellow,
                    onPressed: (){
                      soundPlayer(5);
                    },
                  ),
                ),
                Expanded(
                  child: FlatButton(
                    color:Colors.greenAccent,
                    onPressed: (){
                      soundPlayer(6);
                    },
                  ),
                ),
                Expanded(
                  child: FlatButton(
                    color:Colors.cyanAccent,
                    onPressed: (){
                      soundPlayer(7);
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
